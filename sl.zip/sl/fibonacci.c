#include <stdlib.h>
#include <unistd.h>

void my_putchar(char c)
{
    write(1, &c, 1);
}

void my_putstr(char *str)
{
    int i = 0;
    while (str[i]) {
        my_putchar(str[i]);
        i++;
    }
}

//Fibonnaci on doit vérifier si une suite est une suite de fibonnaci
//On fait la somme des deux précédents pour voir si ça donne le troisième
//En gros je stocke les deux premiers dans a et b
//Et je les compare au troisième
//i % 2 == 0 C'est pour vérifier.. si le i est pair ou pas
//Si le i est pair.. je change la valeur du deuxième nombre
//Si c'est impaire je change la valeur du deuxième
void check_fibonnaci(char **av)
{
    int i = 3;
    int a = atoi(av[1]);
    int b = atoi(av[2]);

    while (av[i]) {
        if (a + b != atoi(av[i])) {
            my_putstr("Not a Fibonacci sequence\n");
            return;
        }
        if (i % 2 == 0)
            b = atoi(av[i]);
        else
            a = atoi(av[i]);
        i++;
    }
    my_putstr("OK\n");
}

int main(int ac, char **av)
{
    if (ac != 1 && ac <= 3 ) {
        my_putstr("Not a Fibonacci sequence\n");
        return 0;
    }
    if (ac > 3) {
        check_fibonnaci(av);
        return 0;
    }
    return 84;
}