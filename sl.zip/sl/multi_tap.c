#include <string.h>
#include <unistd.h>

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_strlen(char *str)
{
    int i = 0;
    while (str[i])
        i++;
    return i;
}

void display(char ch, char c, char prec)
{
    int i = 0;
                ///abcdefghijklmnopqrstuvwxyz
    char text[] = "22233344455566677778889999";
    //En gros l'idée c'est que lorsque je prends un caractère je le convertis en miniscule
    //Lorsque je fais le moins (-) 'a'.. 
    //end = 0 si le charactère est 'a'
    //end = 1 si le charactère est 'b'.. ainsi de suite
    //Et si tu remarque text[end] me permet d'avoir la touche sur laquelle je dois appuyer pour avoir le caractère
    //J'espère que tu captes le lien unh
    int end = (ch - 'a');
    int n = (prec - 'a');

    //En gros ici.. si les deux caractères sont sur la même touche.. genre je dois afficher "AAAH"
    //J'ai les trois A qui sont sur la même touche genre 2.. mais les touches sont majuscules donc je dois
    //afficher # avant de les afficher.. or si il y a # je dois plus afficher d'espace
    //C'est à dire "aaa" donne "2 2 2".. alors que "AAA" donne "#2#2#2"
    //C'est à dire que je peux pas afficher # et espcace à la fois
    //Du coup depuis l'autre fonction.. j'initialise c à '\0'
    //Quand je l'appelle ici je fais c + ' '
    //C'est à dire que si le c est toujours égale à 0 sa valeur va passer à (' ') dans cette fonction Or
    //Quand j'affiche un dièz # le c passe à c = '#'
    //Alors quand je vais faire c + ' '.. dans cette fonction sa valeur sera égale à ('#' + ' ')
    if (c == ' ' && text[end] == text[n])
        my_putchar(' ');
    //Bref.. supposons que je veuille afficher c.. je dois faire 222
    //Donc je fais ('c' - 'a') ce qui donne 2
    //text[2] = '2'
    //Du coupe je commence par parcourir text.. et j'affiche tous les '2' qu'il y a jusqu'a la position 2
    //C'est àa ça que sert la boucle
    while (i <= end) {
        if (text[i] == text[end])
            my_putchar(text[i]);
        i++;
    }
}

//Le projet de gérer l'affichage d'une chaine comme si on utilisait un phone à touche
//Si la lettre est majuscule on affiche un dièz '#'
//Si c'est un espace on affiche zéro '0'
//Si deux lettres successives sont sur la même touche.. genre a et b.. on affiche un espace entre les deux.. 
//Ce qui signifie en vrai qu'on attend un peu
void multi_tap(char *str)
{
    char prec = '\0';
    char c = '\0';
    //Le prec me permet de garder le caractère précédent afin de pouvoir vérifier si ils sont sur la même touche
    //Le c tu vas comprendre son utilité dans l'autre fonction display()

    for (int i = 0; str[i] != '\0'; i++) {
        //Si le caractère est majuscule je le convertis en miniscules
        //Et le C passe à '#' -- L'autre fonction explique pourquoi
        if (str[i] >= 'A' && str[i] <= 'Z') {
            str[i] += 32;
            my_putchar(c = '#');
        }
        //Quand c'est miniscule je passe à l'affichage
        if (str[i] >= 'a' && str[i] <= 'z')
            display(str[i], c + ' ', prec);
        //Si c'est un espace j'affiche 0
        if (str[i] == ' ')
            my_putchar('0');
        prec = str[i];
        c = '\0';
    }
}

//Vérifier que tous les caractères de la chaîne sont alphanumériques soit un espace
int check(char *str)
{
    int i = 0;
    while (str[i]) {
        if (!(str[i] >= 'A' && str[i] <= 'Z') &&
            !(str[i] >= 'a' && str[i] <= 'z') && str[i] != ' ')
            return 84;
        i++;
    }
    return 0;
}

int main(int ac, char **av)
{
    if (ac == 2 && check(av[1]) == 0) {
        multi_tap(av[1]);
        my_putchar('\n');
        return 0;
    }
    return 84;
}